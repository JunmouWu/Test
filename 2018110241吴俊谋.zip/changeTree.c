#include "stdio.h"
#include "stdlib.h" 
#include "math.h"
#include "treeStructure.h"
#include "nodeValue.h"
#include "buildTree.h"
#include "disableTree.h"
#include "changeTree.h"

int addCount = 0; 
int removeCount = 0;
int maxLevel = 6;

// decide if you need to add or remove children

void setFlagValue( Node *node){
	if( node->child[0] == NULL ){
		if( nodeValue(node, 0.0) > 0.5)
			node->flag = 1;
	    if( nodeValue(node, 0.0) < -0.5)
			node->flag = -1;	
	}
	else{
		for( int i=0; i<4; i++)
			setFlagValue( node->child[i] );
	}
	return;
}

// change the tree data structure

void changeTreeStructure( Node *node){
	if( node->child[0] == NULL){
		if( node->flag == 1 && node->level < maxLevel){
			makeChildren( node );
			addCount ++;
		}
	}
	else{
		if( ( node->child[0]->flag == -1 ) && ( node->child[1]->flag == -1 ) && ( node->child[2]->flag == -1 ) && ( node->child[3]->flag == -1 )){
			removeChildren( node );
			removeCount ++;
	    }
	    else{
	    	for(int i=0; i<4; i++)
			changeTreeStructure ( node->child[i] ); 
		}
	}	
	//printf("%d nodes added, %d nodes removed.\n", 4*addCount, 4*removeCount);       for task3, not used in tesk3-extended
	return;
}

// continue running the Task 3 algorithm until the tree does not change

void adapt( Node *node ){
	if( addCount == 0 && removeCount == 0){
		;
	}
	else{
		addCount = 0;
		removeCount = 0;
		setFlagValue( node );
		changeTreeStructure( node );
		printf("%d nodes added, %d nodes removed\n", 4*addCount, 4*removeCount);
		adapt( node );
	}
}
