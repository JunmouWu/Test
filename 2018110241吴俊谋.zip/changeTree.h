// global variables initiation, function definitions

int addCount;
int removeCount;
void setFlagValue( Node *node );
void changeTreeStructure( Node *node );
void adapt( Node *head );

