#include "stdio.h"
#include "stdlib.h"

#include "treeStructure.h"
#include "disableTree.h"

// free all the memory used by the tree
 	
void destroyTree(Node* node){
	if( node->child[0] == NULL ){
		free(node);
		node = NULL;
	}
	else{
		for(int i=0; i<4; i++){
			destroyTree( node->child[i] );
		}
		free( node );
		node = NULL;
	}
	return ;
}

// remove the 4 children from a given node and frees the memory used

void removeChildren( Node *parent ) {
	if( parent->child[0] == NULL){
		;
	}
	else{
		for(int i=0; i<4; ++i){
			free( parent->child[i] );
			parent->child[i] = NULL;
		}
	}

	return;	
}


