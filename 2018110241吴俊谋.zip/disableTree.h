// function definitions

void destroyTree( Node* node );
void removeChildren( Node *parent );

