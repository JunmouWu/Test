#include "stdio.h" 
#include "stdlib.h"

#include "treeStructure.h"
#include "writeTree.h"
#include "buildTree.h"
#include "disableTree.h"
#include "changeTree.h"
 

// main

int main( int argc, char **argv ) {

  Node *head;

  // make the head node
  head = makeNode( 0.0,0.0, 0 );  
  //grow a tree
  growTree( head );
  growTree( head );
  growTree( head );
  
  setFlagValue( head );
  changeTreeStructure( head );
  printf( "%d nodes added, %d nodes removed.\n", 4*addCount, 4*removeCount ); 
  adapt( head );
   
  //removeChildren( head->child[1]);
  //removeChildren( head->child[0] );
  // print the tree for Gnuplot
  writeTree( head );
  //destroyTree( head );
  destroyTree( head );
 

  return 0;
}
