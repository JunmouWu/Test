// function definitions

double nodeValue( Node *node, double time );
double value( double x, double y, double time ); 

